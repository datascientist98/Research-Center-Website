<?php
    $rfield = $iname =$instrID = "";
    $received = NULL;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $rfield = clean_input($_POST["rfield"]);
        $iname = clean_input($_POST["iname"]);
        $instrID = clean_input($_POST["instrID"]);
        
      
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $stmt = $conn->prepare("INSERT INTO facility (instrID, iname, rfield) VALUES (?,?,?)");
        $stmt->bind_param("dss", $instrID, $iname, $rfield);    
        $stmt->execute();
        $stmt->close();
        $conn->close();
        echo "<script type='text/javascript'> window.alert('Record Inserted Successfully') </script>";
        header("location: http://localhost/Research_Centre/facility.php"); 
    }

    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>