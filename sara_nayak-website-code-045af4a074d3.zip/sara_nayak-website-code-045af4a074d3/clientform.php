

<?php
     $cname = $cphoneno = $user = $pass = $caddress = $cemail = "";
    $received = NULL;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$cid = clean_input($_POST["cid"]);
        $cname = clean_input($_POST["cname"]);
        $cphoneno = clean_input($_POST["cphoneno"]);
        $caddress = clean_input($_POST["caddress"]);
        $cemail = clean_input($_POST["cemail"]);
        $user = clean_input($_POST["user"]);
        $pass = clean_input($_POST["pass"]);
      
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $stmt = $conn->prepare("INSERT INTO client (cname, cphoneno, caddress, cemail, user, pass) VALUES (?, ?, ?, ?, ?, ?)");
        var_dump($stmt);
        $stmt->bind_param("sdssss", $cname, $cphoneno, $caddress, $cemail, $user, $pass);    
        $stmt->execute(); 
        $stmt->close();
        $conn->close();
        echo "<script type='text/javascript'> window.alert('Record Inserted Successfully'): window.location.href='login.php' </script>";
        header("location: http://localhost/Research_Centre/login.php"); 
    }

    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>