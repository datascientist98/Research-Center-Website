<?php
    $EID = $ename = $ephoneno = $qualification = $user_emp = $pass_emp = "";
    $received = NULL;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $EID = clean_input($_POST["EID"]);
        $ename = clean_input($_POST["ename"]);
        $ephoneno = clean_input($_POST["ephoneno"]);
        $qualification = clean_input($_POST["qualification"]);
        $user_emp = clean_input($_POST["user_emp"]);
        $pass_emp = clean_input($_POST["pass_emp"]);
      
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $stmt = $conn->prepare("INSERT INTO employee (EID, ename, ephoneno, qualification, user_emp, pass_emp) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("dsdsss", $EID, $ename, $ephoneno, $qualification, $user_emp, $pass_emp);    
        $stmt->execute();
        $stmt->close();
        $conn->close();
        echo "<script type='text/javascript'> window.alert('Record Inserted Successfully') ): window.location.href='emplogin.php'</script>";
        header("location: http://localhost/Research_Centre/emplogin.php"); 
    }

    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>