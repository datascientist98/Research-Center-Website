<!DOCTYPE html>
<html>
    <head>
        <title>CLIENT LOGIN </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="other/jquery.min.js"></script>
        <script src="other/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script type='text/javascript'>
            function validation(){
                if (document.login.user.value == ""){
                    alert("Username should not be empty")
                    return false;
                }
                if (document.login.pass.value == ""){
                    alert("Password should not be empty")
                    return false;
                }
                
                return true;
            }       
        </script>
        <style>
		body{
		background-image:url('http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-designs-7.jpg');
                background-repeat:no-repeat;
                background-size:cover;
                
		}
		th,td{

			padding:5px;
		}
		td input,select{
			width: 100%;
    		height: 30px;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
		
        </style>
    </head>
    <body>
         <div class ="container">
             <div class ="form-group">
        <div style="padding:15x">
	 <center><h1 style="color:black"> LOGIN</h1></center>
         <br>
         
         <br>
         <center><h3 style="color:black">Please enter the following information</h3></center>
         <br>
         
         
	</div>
        <form name='login' id="login" method="post" action="loginpage.php"  onsubmit="return validation()" autocomplete="off">
                          <center>

            <table>
                <tr>
                    <td>USERNAME</td> <td><input type="text" name="user" id="user" placeholder="Enter username"> </td>
                </tr>
                <br>
                
                <tr>
                    <td>PASSWORD </td> <td><input type="password" name="pass" id="pass" placeholder="Enter password"> </td>
                </tr>
                                                           
                <tr>                    
                    <td></td>
                    <td> <input type="submit"  name="submit" value="Login"> </button> </td>
                    <td> <input type="reset"   name="Cancel" value="Cancel"> </button> </td>
                </center>
                </tr>                
            </table>
        </form>
       
         </div>
    </body>
</html>