<!DOCTYPE html>
<html>
    <head>
        <title> WELCOME </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="other/jquery.min.js"></script>
        <script src="other/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
       
        <style>
		body{
		background-image:url('https://i.pinimg.com/originals/08/8e/8c/088e8c2ba04c4361ae2bb09a93921ef8.png');
		background-repeat:no-repeat;
                background-size:cover;
		}
		th,td{

			padding:5px;
		}
		td input,select{
			width: 100%;
    		height: 30px;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
		body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: navy;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 50%;
  
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
               body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  background-color: black;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: white;
  text-align: center;
  padding: 20 px;
  text-decoration: none;
  font-size: 30 px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}


@media (max-width: 600px) {
    nav, article {
        width: 100%;
        height: 100%;
    }
}
footer {
    background-color: black;
    padding: 10px;
    text-align: center;
    color: white;
}
.address {
    text-align : right
}
.move {
    text-align : left
}
article {
    float: center;
    padding: 20px;
    width: 100%;
    background-image:url('https://i.pinimg.com/originals/08/8e/8c/088e8c2ba04c4361ae2bb09a93921ef8.png');
    height: 300px; 
}

		
	</style>
        </head>
        <body>
            
        <div class ="container">
            <div class="header">
                <p> <div style="color : white"> <center> <strong> Center for Research Consultancy and Technical Services </strong> </center></div> </p> 
                <p > <div class= header-right style="color : white" > Call us at : </div> </p>
            <br>
            <p> <div class= header-right style="color : white"> Email us at : </div> </p>
            </div>
             <div class="topnav" id="myTopnav">
        
        <a href="home.php" class="active">Home</a>
         <a href="about.php">About</a>
         <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        <a href="#news">News</a>
        <div class="dropdown">
            <button class="dropbtn"> Services
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="foodtest.php">Food Testing</a>
                <a href="pharmtest.php">Pharmaceutical and Cosmetics Testing</a>
                <a href="environtest.php">Environmental Testing</a>
                <a href="#">Water Testing</a>
            </div>
        </div> 
        <div class="dropdown">
            <button class="dropbtn"> Facilities
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="#">facility 1</a>
                <a href="#">facility 2</a>
                <a href="#">facility 3</a>
            </div>
        </div> 
        <a href="help.php">Help</a>
        <a href="location.php">Location</a>
        <a href="#">FAQ</a>
        <a href="bill.php">Billing</a>
        <a href="logout.php">Log Out </a>
        
  </div>
            <center>
             <div style="padding:15x">
                 <br>
                 <br>
                            

              <center>         
             
             
             
            <div class="slideshow-container">
            <div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-images-3.jpg" style="width:100%">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-images-3.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-images-3.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

          
                
                    <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<hr>
<section>
<article>
    
    <h1> <center> <strong> Food Testing </strong> </center> </h1>
    <p><img src="https://4.imimg.com/data4/DQ/YX/MY-33294162/food-testing-500x500.jpg" alt="Food testing" style="float:right;width:250px;height:220px;">
We offer a single point solution to all the food testing needs of industry for both domestic and export markets. We carry out following major activities with respect to food products...
    </p>
    
    <div class = "move" > <center> <a href="foodtest.php"  > Know more</a> </center> </div> 
    
  </article>
</section>

<section>
<article>
    <hr>
    <h1> <center> <strong> Pharmaceutical and Cosmetics Testing  </strong> </center> </h1>
    <p><img src="https://www.chemika.com.au/images//Photographer_images/chemistry/simin_titration_2013-07-18_14.25.18-1.jpg" alt="Pharmaceutical and Cosmetics testing" style="float:left;width:250px;height:220px;">
We undertake testing & analysis of wide range of  Pharmaceuticals & Cosmetics products as per National & International standards such as IP, EP, USP, BP, JP or others and also as per specific requirement.
We undertake testing for following parameters.
    </p>
    
    <div class = "address" > <a href="pharmtest.php"  > Know more</a> </div> 
  </article>
</section>
<section>
<article>
    <hr>
    <h1> <center> <strong> C.	Environmental Testing </strong> </center> </h1>
    <p><img src="https://www.openpr.com/images/articles/R/7/R70324242_g.jpg" alt="Environment testing" style="float:right;width:250px;height:220px;">
Our laboratory provides a complete range of services for organic and inorganic analysis, using modern instrumental analytical techniques, enabling us to meet the environmental analytical needs of customers.

    </p>
    
    <div class = "move" > <a href="environtext.php"  > Know more</a> </div> 
  </article>
</section>
<section>
<article>
    <hr>
    <h1> <center> <strong> Water Testing </strong> </center> </h1>
    <p><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgqiur61WWQk9p2KH1wsWJei9MFps3EdQRJq6hlCdWstuRnq3rcg" alt="Environment testing" style="float:left;width:250px;height:200px;">
We routinely carry out Water testing as per specification laid down by IS, IP or other methods.
    
    </p>
    
    <div class = "address" > <a href="water.php"  > Know more</a> </div> 
  </article>
</section>

<footer>
    <p class ="address" style ="color : white" > Dr. Shubhada Nayak <br>
        Mobile Number : 9869845255 <br>
        Email: shubhadanayak@kbpcollegevashi.edu.in <br>
        Mr. Hiren Chavan <br>
        Mobile Number : 9773464357 <br>
        Email: hirenchavan@kbpcollegevashi.edu.in
    </p>
    
    
</footer>
        </body>
        </html>