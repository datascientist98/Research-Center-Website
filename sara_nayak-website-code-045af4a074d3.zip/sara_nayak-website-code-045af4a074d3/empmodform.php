<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $EID = clean_input($_POST["EID"]);
        $ename = clean_input($_POST["ename"]);
        $ephoneno = clean_input($_POST["ephoneno"]);
        $qualification = clean_input($_POST["qualification"]);
        $user_emp = clean_input($_POST["user_emp"]);
        $pass_emp = clean_input($_POST["pass_emp"]);
        
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        if(isset($_POST['Update'])) {
            $stmt = $conn->prepare("UPDATE employee set ename = ?, ephoneno = ?, qualification = ?, user_emp = ?, pass_emp = ? where EID = ?");
            $stmt->bind_param("sdsssd", $ename, $ephoneno, $qualification, $user_emp, $pass_emp, $EID);    
            $stmt->execute();
        } else if (isset($_POST['Delete'])) {
            $stmt = $conn->prepare("DELETE from employee where EID = ?");
            $stmt->bind_param("d", $EID);    
            $stmt->execute();
        } else{
            echo 'Something went wrong';
        }
        $conn->close();        
        header("location: http://localhost/Research_Centre/empmod.php"); 
    }
    
    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>