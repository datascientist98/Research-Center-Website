<?php
    $BID = $cid = $cname = $amount = $centre_gst = $client_gst = "";
    $received = NULL;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $BID = clean_input($_POST["BID"]);
        $cid = clean_input($_POST["cid"]);
        $cname = clean_input($_POST["cname"]);
        $amount = clean_input($_POST["amount"]);
        $centre_gst = clean_input($_POST["centre_gst"]);
        $client_gst = clean_input($_POST["client_gst"]);
        
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $stmt = $conn->prepare("INSERT INTO bill (BID, cid, cname, amount, centre_gst, client_gst) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ddsddd", $BID, $cid, $cname, $amount, $centre_gst, $client_gst);    
        $stmt->execute();
        $stmt->close();
        $conn->close();
        echo "<script type='text/javascript'> window.alert('Record Inserted Successfully') </script>";
        header("location: http://localhost/Research_Centre/bill.php"); 
    }

    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>