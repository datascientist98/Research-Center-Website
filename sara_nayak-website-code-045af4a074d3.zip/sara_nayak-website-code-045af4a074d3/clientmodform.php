<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cid = clean_input($_POST["cid"]);
        $cname = clean_input($_POST["cname"]);
        $cphoneno = clean_input($_POST["cphoneno"]);
        $caddress = clean_input($_POST["caddress"]);
        $cemail = clean_input($_POST["cemail"]);
        $user = clean_input($_POST["user"]);
        $pass = clean_input($_POST["pass"]);
       
        
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        if(isset($_POST['Update'])) {
            $stmt = $conn->prepare("UPDATE client set cname = ?, cphoneno = ?, caddress = ?, cemail = ?, user = ?, pass = ? where cid = ?");
            $stmt->bind_param("sdssssd", $cname, $cphoneno, $caddress, $cemail, $user, $pass, $cid);    
            $stmt->execute();
        } else if (isset($_POST['Delete'])) {
            $stmt = $conn->prepare("DELETE from client where cid = ?");
            $stmt->bind_param("d", $cid);    
            $stmt->execute();
        } else{
            echo 'Something went wrong';
        }
        $conn->close();        
        header("location: http://localhost/Research_Centre/clientmod.php"); 
    }
    
    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>