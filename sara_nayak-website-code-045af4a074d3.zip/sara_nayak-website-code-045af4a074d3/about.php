<!DOCTYPE html>
<html>
    <head>
        <title> ABOUT US </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
		body{
		background-image:url('http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-designs-7.jpg');
                background-repeat:no-repeat;
                background-size:cover;
                
		}
		th,td{

			padding:5px;
		}
		td input,select{
			width: 100%;
    		height: 30px;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
                .btn {
  background-color: green;
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
}

.btn:hover {opacity: 1}
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
		
        </style>
        <body>
         <div class ="container">
             <div class="topnav" id="myTopnav">
         <a href="about.php">About</a>
         <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        <a href="home.php" class="active">Home</a>
        <a href="#news">News</a>
        <div class="dropdown">
            <button class="dropbtn"> Services
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="foodtest.php">Food Testing</a>
                <a href="pharmtest.php">Pharmaceutical and Cosmetics Testing</a>
                <a href="environtest.php">Environmental Testing</a>
                <a href="#">Water Testing</a>
            </div>
        </div> 
        <div class="dropdown">
            <button class="dropbtn"> Facilities
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="#">facility 1</a>
                <a href="#">facility 2</a>
                <a href="#">facility 3</a>
            </div>
        </div> 
        <a href="help.php">Help</a>
        <a href="location.php">Location</a>
        <a href="#">FAQ</a>
        
  </div>
        <div style="padding:15x">
	 <center><h1 style="color:black">About Us </h1></center>
       
	</div>
             <p> Rayat Shikshan Sanstha is the largest educational organization in India which was established in 1919 by Padmabhushan Karmaveer Bhaurao Patil. 
                 Currently it has 730 branches spread over 14 districts of Maharashtra and one district of Karnataka. Karmaveer Bhaurao Patil College, Vashi, is one of the finest institutes of Rayat Shikshan Sanstha, 
                 established in 1979. It is an ISO 9001:2015 certified institute. The college has been reaccredited in the third cycle by NAAC with 'A+' grade and CGPA 3.53 in 2017. <br>
                 Along with Excellence in Education the institute now aims to spread its wings in product and process based Research and Services. <br>
                 Karmaveer Bhaurao Patil College proudly announces opening of "Center for Research, Consultancy and Technical Services" (CRCTS) located in the college campus with a fully GLP compliant
                 state-of-the-art Research, Consultancy and Testing facilities and competent staff to handle all industry based queries.<br>
                 Wwe are committed to provide our customers the latest and most advanced technologies which help them solve problems and deliver the highest quality products to the consumers. <br>
                 Our laboratory is equipped wth the latest analytial equipment like Atomic Sbsorption Sprectrophotometer, CHNS/O Elemental Analyser, HPLC, GC, Vitek2 (Automated Microbial Identification System), Phase Contrast Microscope, 
                 UV Visible Spectrophotometer, Ultra-Sonicator, Flame Photometer, etc.<br>
                 We Provide consultancy and testing services in the field of food, pharmaceuticals, cosmetics, water, environment etc. We also undertake contract research and provide Rapid Microbial Identification services using VITEK-2. 
                 <br>
             <p> VISION:
Our vision is to provide the industry with independent laboratory analytical services that are highest quality achievable, accurate and timely while also meeting and exceeding our client’s expectations.
             </p>
             
             <br>
             <p>
                 MISSION:
We strive to offer advanced technology, technical expertise for all segments of each industry we serve, and to continually improve our quality, processes, and knowledge base through research, study and collaboration.

 
             </p>
                 
             
         </div>
        </body>
</html>
