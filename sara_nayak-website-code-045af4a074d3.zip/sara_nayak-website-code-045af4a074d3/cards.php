<!DOCTYPE html>
<html>
<head>
	<title> HOW CAN WE HELP YOU ?</title>
	<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="other/css/bootstrap.min.css" type="text/css"/>
        <link rel="stylesheet" href="other/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="other/css/bootstrap-grid.min.css" type="text/css"/>
        <link rel="stylesheet" href="other/css/bootstrap.css" type="text/css">
        <script src="other/jquery.min.js"></script>
        <script src="other/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script type='text/javascript'>
                
        </script>
        <style>
		body{
                    background-image:url('http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-hd.png');
		  background-repeat:no-repeat;
                background-size:cover;
                
		}
		th,td{
                        
			padding:5px;
		}
		td input,select{
			width: 100%;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
		
        </style>
        
</head>
<body>
    
  <div class="container">
      <center><h2> FACILITIES </h2></center>
  
  <div class="card-deck">
    <div class="card bg-warning" style ="width: 100%">
      <div class="card-body text-center">
        <h4 class="card-title"> Info 1</h4>
        <p class="card-text"> sample details  </p>
        <p class="card-text"> sample details </p>
        <p class="card-text"> sample details</p>
        <a href="#" class="btn btn-primary"> Know more</a>
      </div>
    </div>
    <div class="card bg-success">
      <div class="card-body text-center">
        <h4 class="card-title">Info 1</h4>
        <p class="card-text">  sample details </p>
        <p class="card-text"> sample details </p>
        <p class="card-text"> sample details </p>
        <a href="#" class="btn btn-primary"> Know more</a>
      </div>
    </div>
    <div class="card bg-warning">
      <div class="card-body text-center">
        <h4 class="card-title">Info 1</h4>
        <p class="card-text">  sample details </p>
        <p class="card-text"> sample details </p>
        <p class="card-text"> sample details </p>
        <a href="#" class="btn btn-primary"> Know more</a>
      </div>
    </div>
    <div class="card bg-success">
      <div class="card-body text-center">
        <h4 class="card-title">Info 1</h4>
        <p class="card-text">  sample details </p>
        <p class="card-text"> sample details </p>
        <p class="card-text"> sample details </p>
        <a href="#" class="btn btn-primary"> Know more</a>
      </div>
    </div>
  </div>
</div>



</body>
</html>
