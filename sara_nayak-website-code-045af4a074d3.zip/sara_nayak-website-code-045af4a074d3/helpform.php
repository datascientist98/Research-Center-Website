

<?php
    $name = $phone = $email = $location = $question = "";
    $received = NULL;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $name = clean_input($_POST["name"]);
        $phone = clean_input($_POST["phone"]);
        $email = clean_input($_POST["email"]);
        $location = clean_input($_POST["location"]);
        $question = clean_input($_POST["question"]);
      
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $stmt = $conn->prepare("INSERT INTO help (name, phone, email, location, question) VALUES (?, ?, ?, ?, ?)");
        var_dump($stmt);
        $stmt->bind_param("sdsss", $name, $phone, $email, $location, $question);    
        $stmt->execute(); 
        $stmt->close();
        $conn->close();
        echo "<script type='text/javascript'> window.alert('Thank you! We will get in touch with you soon!'): window.location.href='home.php' </script>";
        header("location: http://localhost/Research_Centre/home.php"); 
    }

    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>