<!DOCTYPE html>
<html lang="en">
<head>
<title>Research Centre</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    backround-color: gray;
}

/* Style the header */
header {
    background-color: lightslategray;
    padding: 30px;
    text-align: center;
    font-size: 35px;
    color: black;
}


nav {
    float: left;
    width: 30%;
    height: 500px; 
    background: #A0522D;
    padding: 20px;
    text-align: center;
    font-size: 25px;
    
    
}

/* Style the list inside the menu */
nav ul {
    list-style-type: none;
    padding: 0;
    color: black;
}

article {
    float: left;
    padding: 20px;
    width: 70%;
    background-color: #f1f1f1;
    height: 300px; 
}

/* Clear floats after the columns */
section:after {
    content: "";
    display: table;
    clear: both;
}

/* Style the footer */
footer {
    background-color: lightslategray;
    padding: 10px;
    text-align: center;
    color: black;
}


@media (max-width: 600px) {
    nav, article {
        width: 100%;
        height: 100%;
    }
}
</style>
</head>
<body>


<header>
  <h2>About Research Centre</h2>
</header>
    <div style=overflow-x:auto;">

<section>
  <nav>
    <ul>
      <li><a href="#">facility 1</a></li>
      <li><a href="#">facility 2</a></li>
      <li><a href="#">facility 3</a></li>
    </ul>
  </nav>
  
  <article>
    <h1>Research Centre</h1>
    <p>abcd</p>
    <p>efgh</p>
  </article>
</section>

<footer>
  <p>Footer</p>
</footer>

</body>
</html>

