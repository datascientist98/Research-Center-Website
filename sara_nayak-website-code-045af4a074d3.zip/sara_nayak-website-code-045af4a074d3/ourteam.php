<html>
<head>
     <title> OUR TEAM </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="other/jquery.min.js"></script>
        <script src="other/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","getemp.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
<style>
		body{
		background-image:url('http://backgroundcheckall.com/wp-content/uploads/2017/12/science-background-designs-7.jpg');
                background-repeat:no-repeat;
                background-size:cover;
                
		}
		th,td{

			padding:5px;
		}
		td input,select{
			width: 100%;
    		height: 30px;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
		table,th,td {
                border : 1px solid black;
                border-collapse: collapse;
}
th,td {
  padding: 5px;
}
        </style>
</head>
<body>
    <div class ="container">
 <div style="padding:15x">
	 <center><h1 style="color:black">Our Team </h1></center>
       <h3 style="color:black">Know more about us</h3>
	</div>
<form>
<select name="ourteam" onchange="showUser(this.value)">
  <option value="">Select a person:</option>
  <option value="1">Anne Johnson</option>
  <option value="2">Stella Griffin</option>
  <option value="3">Joseph Anthony</option>
  <option value="4">Brad McGuire</option>
  </select>
</form>
<br>
<div id="txtHint"><b>Employee information will be listed here...</b></div>
    </div>
</body>

</html>