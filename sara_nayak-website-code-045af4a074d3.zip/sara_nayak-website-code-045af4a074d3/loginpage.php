<?php

        $connect = mysqli_connect('localhost', 'root', '');
        $select = mysqli_select_db($connect,'research');
	if (isset($_POST['submit'])) {
		$user = $_POST['user'];
		$pass = $_POST['pass'];
                //echo $user . '<br>';
                //echo $pass . '<br>';
		chckusername($user, $pass);
	}
	function chckusername($user, $pass){
		$connect = mysqli_connect('localhost', 'root', '');
                $select = mysqli_select_db($connect,'research');
		$check = "SELECT * FROM client WHERE user='$user'";
		$check_q = mysqli_query($connect,$check) or die("<div class='loginmsg'>Error on checking Username<div>");
		if (mysqli_num_rows($check_q) >0) {
			chcklogin($user, $pass);
		}
		else{
			echo "<script>window.alert('Invalid username or password! Please try again.'); window.location.href='login.php';</script>";
		}
	}
	function chcklogin($user, $pass){
		$connect = mysqli_connect('localhost', 'root', '');
                $select = mysqli_select_db($connect,'research');
		$login = "SELECT * FROM client WHERE user='$user'  and pass='$pass'";
		$login_q = mysqli_query($connect,$login) or die('Error on checking Username and Password');
		// Mysql_num_row is counting table row
		if (mysqli_num_rows($login_q)>0){
			echo "<script>window.alert('logged in as $user'); window.location.href='home.php';</script>"; 
			$_SESSION['user'] = $user;
			
			
		}
		else {
			
                        echo "<script>window.alert('Invalid username or password! Please try again.'); window.location.href='login.php';</script>";
			
		}
	}
?>



