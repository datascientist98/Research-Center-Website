<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $instrID = clean_input($_POST["instrID"]);
        $iname = clean_input($_POST["iname"]);
        $rfield = clean_input($_POST["rfield"]);
        
              
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Research";

        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        if(isset($_POST['Update'])) {
            $stmt = $conn->prepare("UPDATE facility set iname = ?, rfield = ? where instrID = ?");
            $stmt->bind_param("ssd", $iname, $rfield, $instrID);    
            $stmt->execute();
        } else if (isset($_POST['Delete'])) {
            $stmt = $conn->prepare("DELETE from facility where instrID = ?");
            $stmt->bind_param("d", $instrID);    
            $stmt->execute();
        } else{
            echo 'Something went wrong';
        }
        $conn->close();        
        header("location: http://localhost/Research_Centre/facilitymod.php"); 
    }
    
    function clean_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>