<?php

        $connect = mysqli_connect('localhost', 'root', '');
        $select = mysqli_select_db($connect,'research');
	if (isset($_POST['submit'])) {
		$user_emp = $_POST['user_emp'];
		$pass_emp = $_POST['pass_emp'];
                //echo $user . '<br>';
                //echo $pass . '<br>';
		chckusername($user_emp, $pass_emp);
	}
	function chckusername($user_emp, $pass_emp){
		$connect = mysqli_connect('localhost', 'root', '');
                $select = mysqli_select_db($connect,'research');
		$check = "SELECT * FROM employee WHERE user_emp='$user_emp'";
		$check_q = mysqli_query($connect,$check) or die("<div class='loginmsg'>Error on checking Username<div>");
		if (mysqli_num_rows($check_q) >0) {
			chcklogin($user_emp, $pass_emp);
		}
		else{
			echo "<script>window.alert('Invalid username or password! Please try again.'); window.location.href='login.php';</script>";
		}
	}
	function chcklogin($user_emp, $pass_emp){
		$connect = mysqli_connect('localhost', 'root', '');
                $select = mysqli_select_db($connect,'research');
		$login = "SELECT * FROM employee WHERE user_emp='$user_emp'  and pass_emp='$pass_emp'";
		$login_q = mysqli_query($connect,$login) or die('Error on checking Username and Password');
		// Mysql_num_row is counting table row
		if (mysqli_num_rows($login_q)>0){
			echo "<script>window.alert('logged in as $user_emp'); window.location.href='home1.php';</script>"; 
			$_SESSION['user_emp'] = $user_emp;
			
			//header('Location: navigation.php');
		}
		else {
			echo "<script>window.alert('Invalid username or password! Please try again.'); window.location.href='login.php';</script>";
		}
	}
?>



