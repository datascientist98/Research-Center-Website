<!DOCTYPE html>
<html>
    <head>
        <title> ENVIRONMENTAL TESTING </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script>
            function loadDoc() {
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                    myFunction(this);
                    }
                };
                xhttp.open("GET", "environment.xml", true);
                xhttp.send();
            }
            
        </script>
        <style>
		body{
		background-image:url('https://i.pinimg.com/originals/08/8e/8c/088e8c2ba04c4361ae2bb09a93921ef8.png');
                background-repeat:no-repeat;
                background-size:cover;
                
		}
		th,td{

			padding:5px;
		}
		td input,select{
			width: 100%;
    		height: 30px;
    		
    		box-sizing: border-box;
    		border: 1px solid #ccc;
    		border-radius: 4px;
    	
    		font-size: 15px;
    		resize: none;
		}
                .btn {
  background-color: navy;
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
}

.btn:hover {opacity: 1}
.topnav {
  overflow: hidden;
  background-color: navy;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

.header {
  overflow: hidden;
  background-color: black;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: white;
  text-align: center;
  padding: 20 px;
  text-decoration: none;
  font-size: 30 px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}


@media (max-width: 600px) {
    nav, article {
        width: 100%;
        height: 100%;
    }
}
footer {
    background-color: black;
    padding: 10px;
    text-align: center;
    color: white;
}
.address {
    text-align : right
}
.move {
    text-align : left
}

		
        </style>
        <body>
         <div class ="container">
             <div class="header">
                <p> <div style="color : white"> <center> <strong> Center for Research Consultancy and Technical Services </strong> </center></div> </p> 
                <p > <div class= header-right style="color : white" > Call us at : </div> </p>
            <br>
            <p> <div class= header-right style="color : white"> Email us at : </div> </p>
            </div>
             <div class="topnav" id="myTopnav">
         <a href="about.php">About</a>
         <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        <a href="home.php" class="active">Home</a>
        <a href="#news">News</a>
        <div class="dropdown">
            <button class="dropbtn"> Services
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="foodtest.php">Food Testing</a>
                <a href="pharmtest.php">Pharmaceutical and Cosmetics Testing</a>
                <a href="environtest.php">Environmental Testing</a>
                <a href="water.php">Water Testing</a>
            </div>
        </div> 
        <div class="dropdown">
            <button class="dropbtn"> Facilities
            <i class="fa fa-caret-down"></i>
             </button>
            <div class="dropdown-content">
                <a href="#">facility 1</a>
                <a href="#">facility 2</a>
                <a href="#">facility 3</a>
            </div>
        </div> 
        <a href="help.php">Help</a>
        <a href="location.php">Location</a>
        <a href="#">FAQ</a>
        <a href="logout.php">Logout</a>
        
  </div>
        <div style="padding:15x">
	 <center><h1 style="color:black">Environmental Testing </h1></center>
         <p>Our laboratory provides a complete range oof services for organic and inorganic analysis, using modern instrumental analytical teachniques, enabling us to meet the environmental needs of customers.</p>
         
         
         <p>
             1. Effluent / Waste Water
             <br>
             <br>
             2. Detection and identification of pathogens
             <br>
             <br>
             3. Disintegration test
             <br>
             <br>
             4. Friability test
             <br>
             <br>
             5. Preservative efficacy testing
             <br>
             <br>
             6. Microbiological assays of antibiotics and vitamins
             <br>
             <br>
             7. Testing of impurities and related substances [Residual solvents and organic volatile impurities]
             <br>
             <br>
             8. Identification tests by FTIR
             <br>
             <br>
             9. Sterility Testing
             <br>
             <br>
             10. Limit tests for heavy metals 
             <br>
             <br>
             11. Antimicrobial susceptibility testings<br>
             <br>
             
             
         </p>    
	</div>
             
             <footer>
    <p class ="address" style ="color : white" > Dr. Shubhada Nayak <br>
        Mobile Number : 9869845255 <br>
        Email: shubhadanayak@kbpcollegevashi.edu.in <br>
        Mr. Hiren Chavan <br>
        Mobile Number : 9773464357 <br>
        Email: hirenchavan@kbpcollegevashi.edu.in
    </p>
    
    
</footer>
         </div>
        </body>
</html>
