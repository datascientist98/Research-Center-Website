<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$EID = $ename = $ephoneno = $qualification = "";
$q = intval(filter_input(INPUT_GET, 'q'));

$con = mysqli_connect('localhost','root','','Research');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"Research");
$sql="SELECT * FROM employee WHERE EID = '".$q."'";
$result = mysqli_query($con,$sql);

echo "<table>
<tr>
<th>Employee ID</th>
<th>Employee Name</th>
<th>Employee Phone Number</th>
<th>Employee Qualification</th>

</tr>";
while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
    $employee[] = $row['EID'].$row['ename'].$row['ephoneno'].$row['qualification'];
    echo "<tr>";
    echo "<td>" . $row['EID'] . "</td>";
    echo "<td>" . $row['ename'] . "</td>";
    echo "<td>" . $row['ephoneno'] . "</td>";
    echo "<td>" . $row['qualification'] . "</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
</body>
</html>